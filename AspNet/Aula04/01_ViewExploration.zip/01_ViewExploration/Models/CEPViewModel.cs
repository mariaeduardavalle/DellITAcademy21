namespace _01_ViewExploration.Models;
public class CEPViewModel
{
    public int CEP { get; set; }
    public string Cidade { get; set;}
    public string Estado { get; set;}
    public string Logradouro{get; set;}
    public string Bairro{get; set;}
}
